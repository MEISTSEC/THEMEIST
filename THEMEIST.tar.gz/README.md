# THEMEIST
THEMEIST: A BUFFER OVERFLOW ATTACK FRAMEWORK

"The Meist," is a small project I decided to throw together when I was conducting the Penetration Tester path on TryHackMe.com. I was understanding how to do the buffer overflow exploits at a very basic level and producing shells throughout. However, I did not completely get what was happening within the exploit chain. Even when I followed along with numerous videos and writeups that are out there. By automating the process through writing the code out, it gave me a clearer understanding of how a BoF attack should be staged and executed. Please be advised this project is a work in progress as I am new to the python scripting language. It goes without saying, THEMEIST is an educational tool to be only used for legal purposes.

Cheers,

Meistsec